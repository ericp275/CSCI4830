package p3.pullup_method.org;

public class Employee {

	private String name;

	String getName() {
		return this.name;
	}

}
