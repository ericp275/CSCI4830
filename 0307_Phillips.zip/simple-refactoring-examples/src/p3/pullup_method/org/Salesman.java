package p3.pullup_method.org;

public class Salesman extends Employee {
	
}
